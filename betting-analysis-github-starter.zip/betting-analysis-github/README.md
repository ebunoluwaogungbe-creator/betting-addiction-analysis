# Betting Addiction Among Nigerians — Data Analysis

## Project Overview
This Excel project explores betting patterns in a dataset of 2,000 records. The dashboard compares average weekly bets, reported addiction scores, hours spent betting, betting applications, age groups, gender, and regions.

**Tool:** Microsoft Excel  
**Project type:** Exploratory data analysis and dashboard reporting  
**Dataset size:** 2,000 records (as provided in the workbook)

> **Important context:** The dataset's provenance and collection method were not supplied with the workbook. Treat the results as descriptive analysis of the provided dataset, not as verified estimates for all Nigerians or proof of causation.

## Dashboard Preview
![Betting analysis dashboard](images/betting-dashboard.png)

## Questions Explored
- How does average weekly betting vary by betting application?
- How do average weekly bets compare across age groups and gender?
- How does the average addiction score vary by age group?
- How do average weekly bets compare across regions?
- How do hours spent betting per week vary by application?

## Key Dashboard Figures
The dashboard displays:
- **Total sample:** 2,000
- **Average weekly bets:** 13.13
- **Average addiction score:** 5.54

These are dashboard values and should be interpreted according to the measures and definitions used in the workbook.

## Tools and Techniques
- Microsoft Excel
- PivotTables
- Charts and slicers/filters
- KPI cards and dashboard layout
- Exploratory comparison of categorical groups

## Files in This Repository
- `data/betting-analysis.xlsx` — workbook containing the dataset, Pivot Table sheet, and dashboard.
- `images/betting-dashboard.png` — dashboard screenshot.
- `docs/insights-and-limitations.md` — preliminary observations and interpretation cautions.
- `docs/data-dictionary.md` — field descriptions based on column names.

## How to View the Project
1. Open `data/betting-analysis.xlsx` in Microsoft Excel to explore the workbook.
2. Use the dashboard filters to compare available age groups and betting applications.
3. Review the screenshot in `images/` for a quick preview.

## Limitations
- The source, sampling method, collection period, and representativeness of the dataset are not documented in the provided workbook.
- The term “addiction score” is used as named in the dataset; no clinical interpretation or diagnosis should be inferred.
- Descriptive comparisons do not establish causation.
- Confirm the definitions and calculation logic behind each KPI before using the results in formal reporting.

## Author
**Ebunjah**  
Certified Data Analyst

Add your portfolio and LinkedIn links here before publishing.
