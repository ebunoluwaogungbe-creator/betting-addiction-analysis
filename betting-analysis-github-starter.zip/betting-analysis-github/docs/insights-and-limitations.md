# Dashboard Observations and Limitations

## Figures displayed on the dashboard
- Total sample: 2,000
- Average weekly bets: 13.13
- Average addiction score: 5.54

## Observations visible in the dashboard
- The chart shows the highest average weekly bets for Bet9ja (13.49) and the lowest for Betway (12.71) among the displayed applications.
- The age-group chart displays average addiction scores of 5.62 for Old (41–60), 5.57 for Youth (18–25), and 5.43 for Adult (26–40).
- The regional chart shows average weekly bets ranging from 12.29 in Port Harcourt to 13.50 in Enugu.
- The hours-spent chart displays the highest average for BetKing (10.72) and the lowest for Bet9ja (10.16).

These are observations transcribed from the dashboard screenshot. Recheck them against the workbook before publication, particularly if the filters/slicers affect the displayed values.

## Interpretation cautions
- These are descriptive patterns in the supplied dataset; they do not prove that an app, age group, gender, or region causes higher betting or addiction scores.
- The workbook does not identify the dataset source, collection method, time period, or sampling approach. Do not present the results as representative of all Nigerians without supporting documentation.
- An “addiction score” in a dataset is not, by itself, a clinical diagnosis.
- Avoid stigmatizing individuals or demographic groups when describing the results.

## Before publishing
1. Confirm what one record represents and whether the records are unique participants.
2. Document how average weekly bets, hours spent, and addiction score are calculated.
3. Verify that dashboard values match the workbook's PivotTables and formulas.
4. Record the dataset source only if you have a reliable source statement from your instructor or dataset provider.
