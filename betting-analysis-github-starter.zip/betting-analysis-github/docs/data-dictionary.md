# Data Dictionary

Descriptions below are inferred from the column names in the provided workbook. Confirm them against the original dataset documentation if available.

| Field | Likely meaning |
|---|---|
| Age_Group | Participant age category |
| Gender | Gender category recorded in the dataset |
| Avg_Weekly_Bets | Average or recorded number of bets per week |
| Avg_Bet_Amount ($) | Bet amount in dollars, as labelled |
| Monthly_Income ($) | Monthly income in dollars, as labelled |
| %_Income_Spent_on_Betting | Percentage of income reported as spent on betting |
| Hours_Spent_Betting_Per_Week | Hours spent betting per week |
| Addiction_Level (1–10) | Recorded addiction score on a 1–10 scale |
| Most_Used_Betting_App | Betting application most used |
| Has_Financial_Debt | Whether financial debt is recorded |
| Affected_Work_Life | Whether work life is recorded as affected |
| Relationship_Strained | Whether relationship strain is recorded |
| Years_Betting | Number of years betting |
| Awareness_of_Risk | Recorded awareness-of-risk category |
| Stopped_Betting_Before | Whether stopping betting previously is recorded |
| Region | Region/city category recorded in the dataset |
| Blank/unnamed first column | Appears to contain a record identifier; confirm before relying on it |

The workbook's column labels include dollar currency symbols, but the workbook alone does not establish how currency values were collected or converted. Do not change or infer the currency without confirmation.
